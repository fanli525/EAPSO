%% ********************************************************************************************************************************************************8
% function  y=Diversity(pop,lb,ub)
% Usage:  y=Diversity(pop,lb,ub)
% -----------------------------------------------------------------------------
% -----------------------------------------------------------------------------
% Input:
% lb             - Lower Boundary of Decision Variables
% ub            - Upper Boundary of Decision Variables
%
% Output: 
% y             - diversity
%--------------------------------------------------------------------------------------
% -------------------------------------------------------------------------------------
% Authors:      Fan Li, Xiwen Cai, Liang Gao
% Address       Huazhong University of Science & Technology, Wuhan, PR China;   
% EMAIL:        D201780171@hust.edu.cn
% WEBSITE:    https://sites.google.com/site/handingwanghomepage
% DATE:         July 2020
%This code is part of the program that produces the results in the following paper:
%Li F , Cai X , Gao L . Ensemble of surrogates assisted particle swarm optimization of medium scale expensive problems[J]. Applied Soft Computing, 2018, 74.
%You are free to use it for non-commercial purposes. However, we do not offer any forms of guanrantee or warranty associated with the code. We would appreciate your acknowledgement.
%% *********************************************************************************************************************************************************************************************************


function y=Diversity(pop,lb,ub)

[n,d]=size(pop);
y=0;
mp=mean(pop);
for i=1:n
    a=sqrt(sum((pop(i,:)-mp).^2));
    y=y+a;
end
% ub=max(pop);lb=min(pop);

 L=sqrt(sum((ub-lb).^2));
y=y/(n*L);
        