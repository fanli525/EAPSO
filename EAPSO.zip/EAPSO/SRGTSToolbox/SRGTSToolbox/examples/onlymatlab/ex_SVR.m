%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear all;close all;
set(0,'defaultfigurecolor','w')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Dat.myFN = @  Rastrigin ;  % this could be any user-defined function forrester  noline
Dat.designspace = [0  ;   % lower bound
   0.6 ]*ones(1,8);  % upper bound
Dat.ndv = length(Dat.designspace(1,:));
Dat.npoints =20*Dat.ndv ;
%% create DOE
%% ��̲�ͬ�ĳ�ʼ����Ʋ�����Ӧ�ں����ռ�������ֲ�
Doe=@DOEOLHS ;
[Xtrain Ytrain]=my_initial(Dat,Doe);
%% create DOE
% ��̲�ͬ�ĳ�ʼ����Ʋ�����Ӧ�ں����ռ�������ֲ�
ntests=2;
[Xtest Ytest]=my_test(Dat,ntests);
%% Build Model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit surrogate
Tmax=1;

for i=1:Tmax
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % fit surrogate
    srgtOPT = srgtsSVRSetOptions(Xtrain,Ytrain);
    srgtSRGT = srgtsSVRFit(srgtOPT);
    
    [PRESSRMS, eXV, yhatXV, predvarXV, srgtSRGTXV, srgtOPTXV] = srgtsCrossValidation(srgtOPT);
    
   predy    = srgtsSVREvaluate(Xtest, srgtSRGT);
    
    CRITERIA = srgtsErrorAnalysis(srgtOPT, srgtSRGT, Ytest,predy)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    

    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % plots
    if Dat.ndv==1
     figure (i)
       %   figure (1)
     %   subplot(Tmax,1,i)
        plot(Xtrain,Ytrain, 'ok','linewidth',1.5)
        hold on
        plot(Xtest, Ytest, 'k','linewidth',2)
        hold on
        plot(Xtest, predy, '--b','linewidth',2)
        hold on
   %    plot(Xtest, error_pred, '--r','linewidth',2)
        hold on
      plot(Xtest, abs(Ytest-predy), 'r','linewidth',2)
        set(gca,'FontSize',12)
        set(gca,'linewidth',1.7);
elseif Dat.ndv==2
    X1 = reshape(Xtest(:,1), ntests, ntests); X2 = reshape(Xtest(:,2), ntests, ntests);
    predy = reshape(predy, size(X1));
    Ytest = reshape(Ytest , size(X1));
    figure(2), mesh(X1, X2, predy );shading interp
        figure(3), mesh(X1, X2, Ytest );shading interp

    hold on,
    plot3(Xtrain(:,1),Xtrain(:,2),Ytrain,'.k', 'MarkerSize',10)
    figure(4), contour(predy);
    figure(5), contour(Ytest);
    else 
        figure
        plot(Ytest,'linewidth',1.5)
        hold on
        plot(predy,'linewidth',1.5)
        set(gca,'FontSize',12)
        set(gca,'linewidth',1.7);
end
    



