%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;close all;
clear all;
 set(0,'defaultfigurecolor','w') 
 set(gca, 'Fontname', 'Times New Roman','FontSize',12);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% basic information about the problem
myFN    = @noline1;  % this could be any user-defined function
myFNOPT = 1;

designspace = [0;  % lower bound
               1]; % upper bound

ndv = size(designspace, 2);     

% create DOE
npoints = 5;
X = srgtsScaleVariable(srgtsDOETPLHS(npoints, ndv), ...
    [zeros(1, ndv); ones(1, ndv)], ...
    designspace);
Y = feval(myFN, X, myFNOPT);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% fit kriging
srgtOPT  = srgtsKRGSetOptions(X, Y);
srgtSRGT = srgtsKRGFit(srgtOPT);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% run EGO
maxNbCycles  = 5;
[x, y, stateEGO] = srgtsEGO(myFN, myFNOPT, designspace, designspace, ...
     srgtOPT, srgtSRGT, 0, @srgtslcb, maxNbCycles, 'ON')

% [x, y, stateEGO] = srgtsEGO(myFN, myFNOPT, designspace, designspace, ...
%      srgtOPT, srgtSRGT, 0.25, @srgtsProbOfImprovement, maxNbCycles, 'ON')
