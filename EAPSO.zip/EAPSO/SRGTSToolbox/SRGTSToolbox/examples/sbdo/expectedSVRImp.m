function [ExpImp] =expectedSVRImp(pred_x)
global ModelInfo;
yBest = min (ModelInfo.Y);
pred_y = srgtsSVREvaluate(pred_x,ModelInfo.SVRsurrogate);
SSqr = ModelInfo.PREDVAR;
s=abs(SSqr)^0.5;
if s == 0
    ExpImp=0;
else
EITermOne=(yBest-pred_y)*(0.5+0.5*erf((1/sqrt(2))*((yBest-pred_y)/s)));
EITermTwo=s*(1/sqrt(2*pi))*exp(-(1/2)*((yBest-pred_y)^2/SSqr));
ExpImp=-(EITermOne+EITermTwo); 

%ExpImp = normcdf((yBest - pred_y)./s, 0, 1);
end

