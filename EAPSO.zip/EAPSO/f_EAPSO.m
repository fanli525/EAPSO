%% ********************************************************************************************************************************************************8
% function  [fy,fNFE]=f_EAPSO(fun,D,lb,ub)
% Usage:  [fy,fNFE]=f_EAPSO(fun,D,lb,ub)
% -----------------------------------------------------------------------------
% -----------------------------------------------------------------------------
% Input:
% fun           - Name of the problem
% D              - Dimension of the problem
% lb             - Lower Boundary of Decision Variables
% ub            - Upper Boundary of Decision Variables
%
% Output: 
% fy             - the obtained best fitness value
% fNFE         -  the obtained best fitness value in each iteration
%--------------------------------------------------------------------------------------
% -------------------------------------------------------------------------------------
% Authors:      Fan Li, Xiwen Cai, Liang Gao
% Address       Huazhong University of Science & Technology, Wuhan, PR China;   
% EMAIL:        D201780171@hust.edu.cn
% WEBSITE:    
% DATE:         July 2020
%This code is part of the program that produces the results in the following paper:
%Li F , Cai X , Gao L . Ensemble of surrogates assisted particle swarm optimization of medium scale expensive problems[J]. Applied Soft Computing, 2018, 74.
%You are free to use it for non-commercial purposes. However, we do not offer any forms of guanrantee or warranty associated with the code. We would appreciate your acknowledgement.
%% *********************************************************************************************************************************************************************************************************

% function [fy,fNFE]=f_EAPSO(fun,D,lb,ub)
clc;clear; lb=-5;ub=5;D=30; fun=@Ellipsoid;%RosenbrockF22Griewank
Dat.myFN =fun;  
f=Dat.myFN ;
Dat.designspace = [lb;   % lower bound
    ub]*ones(1,D);  % upper bound
Dat.ndv = D;
bound=Dat.designspace;
vbound(2,:)=0.25*(bound(2,:)-bound(1,:));vbound(1,:)=-vbound(2,:);


%% initial sample
k=100;% sample number

LHS =DOELHS(k, D,5);
LHS = ScaleVariable(LHS , [0 1]'*ones(1,D),bound);
Xtrain=LHS;
Ytrain=Dat.myFN(Xtrain);

NFE=k;

%% initial population
[val ind ]=sort(Ytrain);
s=min(60,3*D);                         %population size
pop=Xtrain(ind(1:s),:);fpop=Ytrain(ind(1:s),:);

pbest=pop;   fpbest=fpop;
gbest=Xtrain(ind(1),:);fgbest=fpbest(1);
LHS =DOELHS(s, D,5);
LHS = ScaleVariable(LHS , [0 1]'*ones(1,D),bound);
u=LHS;
u=0.15*u; v=u;         %velocity
w=0.729;   c1=1.491;  c2=1.491;wdamp=0.995;

lw=0.500;                           %initial LCB
%%
lsamp=[];   flsamp=[];  %eps �ֲ�ģ�͵Ĳ���
gsamp=[]; fgsamp=[];     %���ӵ��������е�����ֵ
PAP=[];FPAP=[];
PAU=[];FPAU=[];

dlta=min(sqrt(0.001^2*10),0.00005*sqrt(Dat.ndv)*min(Dat.designspace(2,:)-Dat.designspace(1,:)));

fNFE(1:NFE)=fgbest;

%% iteration
Samp=[Xtrain;gsamp;lsamp];YS=[Ytrain;fgsamp;flsamp];
t=1;maxNFE=50*D; 
rg=1;tep11=0;
while NFE<maxNFE
    G(t,:)=gbest;  FG(t)=fgbest;
    %diversity
    dv(t)=Diversity(pop,bound(1,:),bound(2,:));
        if dv(t)<dv(1)/4
            lw=lw*wdamp;
        end
    %% produce particles
    r=10*D; 
    w=linspace(0.729,0.4,r);
    for i=1:s
        for l=1:r
            for p=1:D
                rw=randperm(r,1);
                new_v(l,p)=w(rw)*v(i,p)+rg*rand*c1*(gbest(p)-pop(i,p))+rand*c2*(pbest(i,p)-pop(i,p));%
            end
            for j=1:D
                if  new_v(l,j)<vbound(1,j)
                    new_v(l,j)=vbound(1,j);
                end
                if  new_v(l,j)>vbound(2,j)
                    new_v(l,j)=vbound(2,j);
                end
            end
            new_pop(l,:)=pop(i,:)+ new_v(l,:);
            for j=1:D
                if new_pop(l,j)<bound(1,j)
                    new_pop(l,j)=bound(1,j);
                end
                if  new_pop(l,j)>bound(2,j)
                    new_pop(l,j)=bound(2,j);
                end
            end
        end
        
        Dts=Samp;Dty=YS;
        predy=mrbf_lcb(Dts,Dty, new_pop,lw);
        
        [val,ind]=sort(predy);
        fnew=Dat.myFN(new_pop(ind(1),:));
        NFE=NFE+1;
        fNFE(NFE)=min(YS);
        Samp=[ Samp;new_pop(ind(1),:)];
        YS=[YS;fnew];
        pop(i,:)=new_pop(ind(1),:);
        v(i,:)=new_v(ind(1),:);
        fpop(i)=fnew;
        gsamp=[gsamp;pop(i,:)];      
        fgsamp=[fgsamp;fpop(i)];
    end
    
    %% update pbest gbest
    for i=1:s
        if fpop(i)<fpbest(i)
            tep11= tep11+1;
            pbest(i,:)=pop(i,:);
            fpbest(i)= fpop(i);
        end
        if fpbest(i)<fgbest
            gbest= pbest(i,:);
            fgbest=fpbest(i);
        end
        Fpbest(i,t)=fpbest(i);
        Pbest{i}(t,:)= pbest(i,:);
    end
    %% local search
        if  NFE>3*maxNFE/4          
            local_search;                   
        end
    t=t+1;
    G(t,:)=gbest;  FG(t)=fgbest;
    NFE,fgbest
end
fy=fgbest;