%% ********************************************************************************************************************************************************8
% Authors:      Fan Li, Xiwen Cai, Liang Gao
% Address       Huazhong University of Science & Technology, Wuhan, PR China;   
% EMAIL:        D201780171@hust.edu.cn
% WEBSITE:    https://sites.google.com/site/handingwanghomepage
% DATE:         July 2020
%This code is part of the program that produces the results in the following paper:
%Li F , Cai X , Gao L . Ensemble of surrogates assisted particle swarm optimization of medium scale expensive problems[J]. Applied Soft Computing, 2018, 74.
%You are free to use it for non-commercial purposes. However, we do not offer any forms of guanrantee or warranty associated with the code. We would appreciate your acknowledgement.
%% *********************************************************************************************************************************************************************************************************


%% local search 
np=10*Dat.ndv ;    %np  
ntrain=size(Samp,1);
if  ntrain>1*np
    dg=pdist2(gbest,Samp);
    [val,ind]=sort(dg);
    Dts=Samp(ind(1:np),:);Dty=YS(ind(1:np));% 
else
    Dts= Samp; Dty=YS;
end



%% PR
lb=min(Dts);ub=max(Dts);
[val,ind]=min(Dty);gbest=Dts(ind,:);
srgtOPT  = srgtsPRSSetOptions(Dts,Dty,2, 'StepwiseSRGTS');%
srgtSRGT = srgtsPRSFit(srgtOPT);
fpre=@(x)srgtsPRSPredictor(x, Dts, srgtSRGT);
xmin=fmincon( fpre,gbest,[],[],[],[],lb,ub);
fxmin=f(xmin);
d1=min(sqrt(sum((repmat(xmin,size(Samp,1),1)-Samp).^2,2)));
if d1>dlta
    Samp=[Samp;xmin]; YS =[YS ;fxmin];
    NFE=NFE+1;fNFE (NFE)= min(YS );
    if fxmin<fgbest
        fgbest=fxmin; gbest= xmin;
        PAU=[PAU; xmin ];FPAU=[FPAU;fxmin ];
    end
end

%% RBF
srgtOPT=srgtsRBFSetOptions(Dts,Dty, @my_rbfbuild, [],'IMQ', 1.0002,1);
srgtSRGT = srgtsRBFFit(srgtOPT);
fpre=@(x)my_rbfpredict(srgtSRGT.RBF_Model, srgtSRGT.P, x);

FE=3000;
options = optimset('Algorithm','interior-point','Display','off','MaxFunEvals',FE,'TolFun',1e-8,'GradObj','off'); % run interior-point algorithm

x  =fmincon( fpre,gbest,[],[],[],[],lb,ub,[],options);

maxu=x ;fx =Dat.myFN (x );
d =min(sqrt(sum((repmat(x  ,size(Samp,1),1)-Samp).^2,2)));
if d>dlta
    Samp=[Samp;x ]; YS =[YS ;fx ];
    NFE=NFE+1;fNFE(NFE )= min(YS );
    PAP=[PAP;x ];FPAP=[FPAP;fx ];
    if fx<fgbest
        fgbest=fx ;gbest=x ;
    end
end

