%% ********************************************************************************************************************************************************8
% function  y=mrbf_lcb(Xtrain,Ytrain,Xtest,w)
% Usage:  y=mrbf_lcb(Xtrain,Ytrain,Xtest,w)
% -----------------------------------------------------------------------------
% -----------------------------------------------------------------------------
% Input:
% Xtrain             - Decision Variables of training points
% Ytrain             - fitness values of training points
% Xtest              - Decision Variables of test points
% w                   - weight coefficient of LCB
%
% Output: 
% y                    - LCB
%--------------------------------------------------------------------------------------
% -------------------------------------------------------------------------------------
% Authors:      Fan Li, Xiwen Cai, Liang Gao
% Address       Huazhong University of Science & Technology, Wuhan, PR China;   
% EMAIL:        D201780171@hust.edu.cn
% WEBSITE:    https://sites.google.com/site/handingwanghomepage
% DATE:         July 2020
%This code is part of the program that produces the results in the following paper:
%Li F , Cai X , Gao L . Ensemble of surrogates assisted particle swarm optimization of medium scale expensive problems[J]. Applied Soft Computing, 2018, 74.
%You are free to use it for non-commercial purposes. However, we do not offer any forms of guanrantee or warranty associated with the code. We would appreciate your acknowledgement.
%% *********************************************************************************************************************************************************************************************************
%% ���������㣬�����Ԥ����Ԥ��ֵ������
function  y=mrbf_lcb(Xtrain,Ytrain,Xtest,w)
%% Build Model
c=1;
% eXVMatrix=[];
for i=1:2
    if i==1
        type='IMQ';
    elseif i==2
         type ='BH';
    elseif i==3
       type='MQ';
    elseif i==4
        type='G';
    elseif i==5
        type='TPS';
    else
        type='CUB';  c=0.001;
    end
    
    srgtOPT=srgtsRBFSetOptions(Xtrain,Ytrain, @my_rbfbuild, [],type, c,1);
    srgtsOPTs{i}=srgtOPT;
    srgtSRGT = srgtsRBFFit(srgtOPT);
    srgtsSRGTs{i}  =  srgtSRGT;
%     [PRESSRMS_RBF, eXV_RBF] = srgtsCrossValidation(srgtOPT);
%     eXVMatrix=[eXVMatrix eXV_RBF];
end
% CMatrix   = srgtsWASComputeCMatrix(Xtrain, eXVMatrix);

WAS_Model   =   'MEAN';%'OWSfull''BestPRESS''NPWS'
WAS_Options = [];% WAS_Options = CMatrix;

srgtOPTWAS  = srgtsWASSetOptions(srgtsOPTs, srgtsSRGTs, WAS_Model, WAS_Options);
srgtSRGTWAS = srgtsWASFit(srgtOPTWAS);

prey   =srgtsWASEvaluate(Xtest, srgtSRGTWAS);
PredVar=srgtsWASPredictionVariance(Xtest, srgtSRGTWAS);
PredsVar=PredVar.^0.5;
y=prey -w*PredsVar;