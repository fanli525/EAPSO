var searchData=
[
  ['imse_2em',['imse.m',['../imse_8m.html',1,'']]],
  ['intrinsiccovariancematrix_2em',['intrinsicCovarianceMatrix.m',['../@_co_kriging_2intrinsic_covariance_matrix_8m.html',1,'']]],
  ['intrinsiccovariancematrix_2em',['intrinsicCovarianceMatrix.m',['../@_basic_gaussian_process_2intrinsic_covariance_matrix_8m.html',1,'']]]
];
