var searchData=
[
  ['kriging',['Kriging',['../class_kriging.html#a6dabe7df003209bca307ddede11796cf',1,'Kriging']]]
];
