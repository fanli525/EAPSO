var searchData=
[
  ['plotkrigingmodel',['plotKrigingModel',['../plot_kriging_model_8m.html#a29c905bdc7256c8e5686001e533e40ca',1,'plotKrigingModel.m']]],
  ['plotscattereddata',['plotScatteredData',['../plot_scattered_data_8m.html#a6a92c3c146e071511106d71a906a9885',1,'plotScatteredData.m']]],
  ['plotvariogram',['plotVariogram',['../class_basic_gaussian_process.html#a386e7a83c73ca994dbbd71cb6d32b0ad',1,'BasicGaussianProcess']]],
  ['powerbase',['powerBase',['../power_base_8m.html#a5fee951babe44909bfeac62f4ce068ae',1,'powerBase.m']]],
  ['predict',['predict',['../class_basic_gaussian_process.html#a9e2941e3d9678f74e6d0a3efec1fbf67',1,'BasicGaussianProcess::predict()'],['../class_kriging.html#a9e2941e3d9678f74e6d0a3efec1fbf67',1,'Kriging::predict()']]],
  ['predict_5fderivatives',['predict_derivatives',['../class_basic_gaussian_process.html#a46aa82637015f1a4b44d7c10dd9a8ee9',1,'BasicGaussianProcess::predict_derivatives()'],['../class_kriging.html#a46aa82637015f1a4b44d7c10dd9a8ee9',1,'Kriging::predict_derivatives()']]],
  ['predict_5flimit',['predict_limit',['../class_basic_gaussian_process.html#a9c19529cc62f25818dd83bfcc5f04ec2',1,'BasicGaussianProcess']]],
  ['predictor',['predictor',['../predictor_8m.html#ac38abd0f72ff331b6335c02b6f2b73e4',1,'predictor.m']]],
  ['pseudolikelihood',['pseudoLikelihood',['../class_basic_gaussian_process.html#a0e6c526cb93c8390a663eb521fae284b',1,'BasicGaussianProcess']]]
];
