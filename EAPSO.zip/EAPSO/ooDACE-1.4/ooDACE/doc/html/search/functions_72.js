var searchData=
[
  ['rcvalues',['rcValues',['../class_basic_gaussian_process.html#a26f6da4585b1d816994698326e44372b',1,'BasicGaussianProcess']]],
  ['regressionfunction',['regressionFunction',['../class_basic_gaussian_process.html#ac745a8382e07ac259e640bccc28657b8',1,'BasicGaussianProcess::regressionFunction()'],['../class_blind_kriging.html#a3376ee794c386f72f68b52a25acfcf36',1,'BlindKriging::regressionFunction()'],['../class_co_kriging.html#a3376ee794c386f72f68b52a25acfcf36',1,'CoKriging::regressionFunction()']]],
  ['regressionmatrix',['regressionMatrix',['../class_basic_gaussian_process.html#ae44978c6189751100fd916abf3be0beb',1,'BasicGaussianProcess::regressionMatrix()'],['../class_blind_kriging.html#ae44978c6189751100fd916abf3be0beb',1,'BlindKriging::regressionMatrix()'],['../class_co_kriging.html#ae44978c6189751100fd916abf3be0beb',1,'CoKriging::regressionMatrix()']]],
  ['runblindkrigingexamples',['runBlindKrigingExamples',['../run_blind_kriging_examples_8m.html#a8ddfadc608642591c673353911a0b8c7',1,'runBlindKrigingExamples.m']]],
  ['runregressiontests',['runRegressionTests',['../run_regression_tests_8m.html#a3559e646a218f209d75cd8408030e39b',1,'runRegressionTests.m']]]
];
