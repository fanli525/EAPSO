var searchData=
[
  ['r',['R',['../class_basic_gaussian_process.html#a09083e327c397ffc75bdc32d72212c70',1,'BasicGaussianProcess']]],
  ['r_5freinterp',['R_reinterp',['../class_basic_gaussian_process.html#a00b7fcf3ebc433ec8a194e250af3c5c3',1,'BasicGaussianProcess']]],
  ['regressionfcn',['regressionFcn',['../class_basic_gaussian_process.html#aca91d2ce9e51ea2232678f0b7a51633f',1,'BasicGaussianProcess']]],
  ['rho',['RHO',['../class_basic_gaussian_process.html#af98ba833fc7505fc46109dad967d01a1',1,'BasicGaussianProcess::RHO()'],['../class_basic_gaussian_process.html#ab2c0bb49bcad323112cc6123065e19ed',1,'BasicGaussianProcess::rho()']]]
];
