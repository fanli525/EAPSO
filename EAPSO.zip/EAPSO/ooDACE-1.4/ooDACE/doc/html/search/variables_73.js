var searchData=
[
  ['sigma',['Sigma',['../class_basic_gaussian_process.html#aadc3e5df63a5f791536a2913c553e4a9',1,'BasicGaussianProcess']]],
  ['sigma2',['sigma2',['../class_basic_gaussian_process.html#abf14251924587034bcf7d18dfa44f805',1,'BasicGaussianProcess::sigma2()'],['../class_basic_gaussian_process.html#afb5a4795c478ca46fc97a9da75ba43a5',1,'BasicGaussianProcess::SIGMA2()']]],
  ['sigma2_5freinterp',['sigma2_reinterp',['../class_basic_gaussian_process.html#a1a0e3be5929e831048c448dd4e2cab50',1,'BasicGaussianProcess']]]
];
