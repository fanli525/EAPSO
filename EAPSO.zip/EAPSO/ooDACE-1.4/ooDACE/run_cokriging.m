clc;clear all;

myFN = @forrester;  % this could be any user-defined function forrester  noline
myFN_L=@L_forrester;
inDim =1 ;

LB = 0;
UB =1;
XL=linspace(LB,UB,5)';
XH=linspace(LB,UB,3)';
YL=L_forrester(XL);
YH=forrester(XH);

samples ={ XL; XH } ;
values={ YL ;YH } ;
%% create DOE


    opts.corrFunc = @corrmatern32;
% build model
fprintf('\nBuilding model...');
tic;
k = oodacefit( samples, values, opts );
t = toc;
%fprintf('done (elapsed time %f s)\n\n', t);
fprintf('done\n\n');

% k represents the kriging approximation and can now be used, e.g.,
x = (LB+UB) ./ 2; % middle of domain
[y s2] = k.predict( x );
[dy ds2] = k.predict_derivatives( x );
xval = k.cvpe(); % Cross Validated Prediction Error (using the mean squared error function)
imseval = k.imse();
marginallik = k.marginalLikelihood();
pseudolik = k.pseudoLikelihood();
sigma2 = k.getProcessVariance();
Sigma = k.getSigma(); % intrinsic covariance matrix

    expr = 'Not available';

fprintf('Evaluating model at (%s).\n', num2str(x, '%g '));
fprintf('Prediction mean = %f. Prediction variance = %f.\n', y, s2);
fprintf('Derivatives of: prediction mean = (%s). prediction variance = (%s).\n', num2str(dy,'%g '), num2str(ds2, '%g '));
fprintf('Leave-one-out crossvalidation: %f (using the mean squared error function).\n', xval);
fprintf('Integrated Mean Square Error: %f.\n', imseval);
fprintf('Marginal likelihood (-log): %f.\n', marginallik);
fprintf('Pseudo likelihood (-log): %f.\n', pseudolik);
fprintf('Process variance: %f\n', sigma2 );
fprintf('Sigma(1,1): %f (first element of intrinsic covariance matrix).\n', full( Sigma(1,1) ) );
fprintf('Formatted regression function: %s\n', expr);

    fprintf('Rho: %f\n', cell2mat( k.getRho() ) );

    
h = plotKrigingModel(k, LB, UB);